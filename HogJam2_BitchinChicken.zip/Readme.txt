This one was compiled on Shawn's laptop.
For some reason the tiling in the platformer and the ending scene's work correctly on Blake's laptop, but not Shawn's.

Shawn added the Title and intro's for each mini-game.